import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { db } from "../firebase";

/**
 * Busca un usuario por DNI en la colección "usuarios".
 * Devuelve null si no existe.
 */
export async function buscarUsuarioPorDni(dni) {
  const ref = doc(db, "usuarios", dni);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    return null;
  }

  return { dni, ...snap.data() };
}

/**
 * Busca la plantilla de rutina correspondiente a un rutinaId.
 * Devuelve null si no existe.
 */
export async function buscarRutina(rutinaId) {
  const ref = doc(db, "rutinas", rutinaId);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    return null;
  }

  return snap.data();
}

/**
 * Avanza el día actual del usuario en loop (1 -> 2 -> ... -> cantidadDias -> 1)
 */
export async function completarDia(dni, diaActual, cantidadDias) {
  const proximoDia = diaActual >= cantidadDias ? 1 : diaActual + 1;
  const ref = doc(db, "usuarios", dni);
  await updateDoc(ref, { diaActual: proximoDia });
  return proximoDia;
}
export async function crearAlumnoConPlantilla({ dni, nombre, rutinaId }) {
  const dniLimpio = String(dni).trim();
  
  const plantillaRef = doc(db, "rutinas", rutinaId);
  const plantillaSnap = await getDoc(plantillaRef);

  let ejerciciosPlantilla = {};
  if (plantillaSnap.exists()) {
    ejerciciosPlantilla = plantillaSnap.data();
  }

  const userRef = doc(db, "usuarios", dniLimpio);
  await setDoc(userRef, {
    nombre: nombre.toLowerCase().trim(),
    cantidadDias: ejerciciosPlantilla.cantidadDias || 3,
    diaActual: 1,
    rutinaId: rutinaId,
    rutina: ejerciciosPlantilla.dias || {}
  });

  return true;
}

/**
 * Sobreescribe la rutina personalizada de un alumno existente
 * (queda guardada en usuarios/{dni}.rutina, con prioridad sobre la plantilla).
 */
export async function actualizarRutinaAlumno(dni, rutina, cantidadDias) {
  const ref = doc(db, "usuarios", dni);
  await updateDoc(ref, { rutina, cantidadDias });
  return true;
}

/**
 * Guarda el mapa completo de pesos de un alumno.
 * Se guarda en usuarios/{dni}.pesos, separado de la rutina, para no pisar
 * la plantilla compartida ni mezclar pesos entre alumnos.
 * La clave de cada entrada es "{diaKey}::{nombreEjercicio}" (no la posición),
 * así el peso queda atado al ejercicio en sí y no se desalinea si el profe
 * reordena o agrega/quita ejercicios de ese día.
 */
export async function guardarPesosAlumno(dni, pesos) {
  const ref = doc(db, "usuarios", dni);
  await updateDoc(ref, { pesos });
  return true;
}