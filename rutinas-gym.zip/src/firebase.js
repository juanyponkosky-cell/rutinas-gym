import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// TODO: reemplazar con el firebaseConfig real que te da la consola de Firebase
// (Configuración del proyecto -> Tus apps -> Web)
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.appspot.com",
  messagingSenderId: "TU_MESSAGING_SENDER_ID",
  appId: "TU_APP_ID",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
